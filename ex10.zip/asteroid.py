from game_util import *

class Asteroid:
    """
    Class that define the object asteroid for the game 'Asteroids'
    """

    def __init__(self, location_x, location_y, v_x, v_y, size=3):
        self.__location_x = location_x
        self.__location_y = location_y
        self.__v_x = v_x
        self.__v_y = v_y
        self.__size = size

    def get_location_x(self):
        """
        Function that gets the location at coordinate x
        :return: the location at coordinate x
        """
        return self.__location_x

    def get_location_y(self):
        """
        Function that gets the location at coordinate y
        :return: the location at coordinate x
        """
        return self.__location_y

    def get_velocity_x(self):
        """
        Function that gets the velocity at coordinate x
        :return: the velocity at coordinate x
        """
        return self.__v_x

    def get_velocity_y(self):
        """
        Function that gets the velocity at coordinate y
        :return: the velocity at coordinate y
        """
        return self.__v_y

    def set_location_x(self, location_x):
        """
        Function that set the location at x coordinate
        :param location_x: the location at x coordinate
        """
        self.__location_x = location_x

    def set_location_y(self, location_y):
        """
        Function that set the location at y coordinate
        :param location_y: the location at y coordinate
        """
        self.__location_y = location_y

    def get_size(self):
        """
        Function that gets the size
        :return: the size of the asteroid
        """
        return self.__size

    def set_size(self, size):
        """
        Function that sets the size
        :param size: size of the asteroid
        """
        self.__size = size

    def get_speed_x(self):
        """
        Function the gets the speed at coordinate x
        :return: the speed at coordinate x
        """
        return self.__v_x

    def get_speed_y(self):
        """
        Function the gets the speed at coordinate y
        :return: the speed at coordinate y
        """
        return self.__v_y

    def set_speed_x(self, speed):
        """
        Function that sets the speed at coordinate x
        :param speed: the speed at coordinate x
        """
        self.__v_x = speed

    def set_speed_y(self, speed):
        """
        Function that sets the speed at coordinate y
        :param speed: the speed at coordinate y
        """
        self.__v_y = speed

    def move_asteroid(self, delta=1):
        """
        Function that move the asteroid in the game
        :param delta:
        """
        self.__location_x += self.__v_x * delta
        self.__location_y += self.__v_y * delta

    def has_intersection(self, obj):
        """
        Function that checks if 2 objects intersect in the game
        :param obj: the specific object we want to check
        :return: True if the is intersection, False otherwise
        """
        return has_intersection_with_object_location(self.__location_x, self.__location_y, obj.get_x_location(),
                                                     obj.get_y_location(), obj.get_radius(), self.get_radius())

    def get_radius(self):
        """
        Function that gets the radius of the asteroid
        :return: the radius of the asteroid
        """
        return self.__size * 10 - 5
