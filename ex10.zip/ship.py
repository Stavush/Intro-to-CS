from game_util import *


class Ship:
    """
    A class that define ship object in the game 'Asteroids'
    """
    def __init__(self, x_location_and_velocity,
                 y_location_and_velocity, heading):
        self.__x_location_and_velocity = x_location_and_velocity  # location and speed on x
        self.__y_location_and_velocity = y_location_and_velocity
        self.__heading = heading
        self.__radius = SHIP_RADIUS

    def get_x_location(self):
        """
        Function that returns the location in the x coordinate
        :return: the location in the x coordinate
        """
        return self.__x_location_and_velocity[0]

    def get_y_location(self):
        """
        Function that returns the location in the y coordinate
        :return: the location in the y coordinate
        """
        return self.__y_location_and_velocity[0]

    def get_x_speed(self):
        """
        Function that returns the speed in the x coordinate
        :return: the speed in the x coordinate
        """
        return self.__x_location_and_velocity[1]

    def get_y_speed(self):
        """
        Function that returns the speed in the y coordinate
        :return: the speed in the y coordinate
        """
        return self.__y_location_and_velocity[1]

    def get_heading(self):
        """
        Function that returns the heading of the ship
        :return: the heading of the ship
        """
        return self.__heading

    def set_heading(self, heading):
        """
        Function that sets the heading of the ship
        """
        self.__heading = heading

    def set_x_location(self, loc):
        """
        Function that sets the location in the x coordinate
        """
        self.__x_location_and_velocity[0] = loc

    def set_y_location(self, loc):
        """
         Function that sets the location in the y coordinate
        """
        self.__y_location_and_velocity[0] = loc

    def set_x_speed(self, speed):
        """
        Function that set the speed in x coordinate
        """
        self.__x_location_and_velocity[1] = speed

    def set_y_speed(self, speed):
        """
        Function that set the speed in y coordinate
        """
        self.__y_location_and_velocity[1] = speed

    def get_radius(self):
        """
        Function that get the radius of the ship
        :return: radius of the ship
        """
        return self.__radius
