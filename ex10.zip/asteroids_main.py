from asteroid import Asteroid
from asteroid import has_intersection_with_object_location
from game_util import *
from ship import Ship
from torpedo import Torpedo


class GameRunner:
    def __init__(self, asteroids_amount):
        self.__screen = Screen()
        self.asteroids_amount = asteroids_amount
        self.__screen_max_x = Screen.SCREEN_MAX_X
        self.__screen_max_y = Screen.SCREEN_MAX_Y
        self.__screen_min_x = Screen.SCREEN_MIN_X
        self.__screen_min_y = Screen.SCREEN_MIN_Y
        ship_location = get_random_location()
        self.__ship = Ship([ship_location[0], 0],
                           [ship_location[1], 0], 0)
        self.__asteroids_amount = asteroids_amount
        self.__asteroids_in_game = self.initialize_asteroids()
        self.__torpedo = []
        self.__tries = INIT_TRIES
        self.points = INIT_POINTS

    def run(self):
        self._do_loop()
        self.__screen.start_screen()

    def _do_loop(self):
        # You should not to change this method!
        self._game_loop()
        # Set the timer to go off again
        self.__screen.update()
        self.__screen.ontimer(self._do_loop, 5)

    def _game_loop(self):
        # check game end
        if self.check_game_end():
            self.__screen.end_game()
            sys.exit()
        # drawing and operations on ship
        self.__screen.draw_ship(self.__ship.get_x_location(),
                                self.__ship.get_y_location(),
                                self.__ship.get_heading())
        self.acceleration_of_ship()
        self.movement_of_ship()
        self.change_direction_of_ship()
        # creating and drawing torpedoes, and checking the collision
        # with asteroids
        self.shoot()
        self.update_torpedoes()
        self.collision_check()
        for torpedo in self.__torpedo:
            self.__screen.draw_torpedo(torpedo, torpedo.get_x_location(),
                                       torpedo.get_y_location(), torpedo.get_heading())
        # update asteroids location
        self.update_asteroids()
        self.update_ship_life()

    def check_game_end(self):
        """
        This function checks if the game is over and prints a message
        explaining the reason.
        :return: True if the game is over or False if not
        """
        title = "Game Over"
        if len(self.__asteroids_in_game) == 0:
            self.__screen.show_message(title, "You won!")
            return True
        elif self.__screen.should_end():
            self.__screen.show_message(title, "Bye Bye")
            return True
        elif self.__tries == 0:
            self.__screen.show_message(title, "You lost!")
            return True
        return False

    def add_ship(self):
        """
        This function constructs a ship and places it upon the screen
        :param self: GameRunner
        """
        self.__screen.draw_ship(self.__ship.get_x_location(), self.__ship.get_y_location(), 0)

    def movement_of_ship(self):
        """
        A function that updates the new spot values. It uses the
        function calc_new_spot to perform the calculation of new spot
        values.
        """
        old_spot_x = self.__ship.get_x_location()
        speed_x = self.__ship.get_x_speed()
        new_spot_x = calc_new_spot(self.__screen_max_x,
                                   self.__screen_min_x, old_spot_x,
                                   speed_x)
        old_spot_y = self.__ship.get_y_location()
        speed_y = self.__ship.get_y_speed()
        new_spot_y = calc_new_spot(self.__screen_max_y,
                                   self.__screen_min_y, old_spot_y,
                                   speed_y)
        self.__ship.set_x_location(new_spot_x)
        self.__ship.set_y_location(new_spot_y)

    def change_direction_of_ship(self):
        """
        This function turns the ship by 7 degrees to the right,
        if right is pressed, or by -7 degrees, if left is pressed
        """
        if self.__screen.is_right_pressed():
            self.__ship.set_heading(self.__ship.get_heading() - 7)
        elif self.__screen.is_left_pressed():
            self.__ship.set_heading(self.__ship.get_heading() + 7)

    def acceleration_of_ship(self):
        """
        Function that accelerate the speed of the ship when button up is
        pressed
        """
        if self.__screen.is_up_pressed():
            old_speed_x = self.__ship.get_x_speed()
            old_speed_y = self.__ship.get_y_speed()
            heading = self.__ship.get_heading()
            new_speed_x = (old_speed_x + math.cos(math.radians(heading)))
            new_speed_y = (old_speed_y + math.sin(math.radians(heading)))
            self.__ship.set_x_speed(new_speed_x)
            self.__ship.set_y_speed(new_speed_y)

    def update_ship_life(self):
        """
        update the life of the ship in case it got hit by an asteroid.
        """
        for asteroid in self.__asteroids_in_game:
            if asteroid.has_intersection(self.__ship):
                if self.__tries >= 0:
                    self.__screen.unregister_asteroid(asteroid)
                    self.__asteroids_in_game.remove(asteroid)
                    self.__tries -= 1
                    self.__screen.remove_life()
                    self.__screen.show_message('Caution!', "You've got hit by an asteroid!")

    def shoot(self):
        """
        A function that creates a torpedo if the player presses space.
        """
        if self.__screen.is_space_pressed():
            if len(self.__torpedo) <= 10:  # assignment 6 in part D
                speed_x = self.__ship.get_x_speed() + 2 * math.cos(
                    math.radians(self.__ship.get_heading()))
                speed_y = self.__ship.get_y_speed() + 2 * math.sin(
                    math.radians(self.__ship.get_heading()))
                current_torpedo = Torpedo([self.__ship.get_x_location(), speed_x],
                                          [self.__ship.get_y_location(), speed_y], self.__ship.get_heading())
                self.__torpedo.append(current_torpedo)
                self.__screen.register_torpedo(current_torpedo)

    def update_torpedoes(self):
        """
        Function that update the location of the torpedo in the game.
        """
        for torpedo in self.__torpedo:
            if torpedo.has_life():
                self.__screen.draw_torpedo(torpedo, torpedo.get_x_location(
                ), torpedo.get_y_location(), torpedo.get_heading())

                new_spot_x = calc_new_spot(self.__screen.SCREEN_MAX_X,
                                           self.__screen.SCREEN_MIN_X,
                                           torpedo.get_x_location(),
                                           torpedo.get_x_speed())
                new_spot_y = calc_new_spot(self.__screen.SCREEN_MAX_Y,
                                           self.__screen.SCREEN_MIN_Y,
                                           torpedo.get_y_location(),
                                           torpedo.get_y_speed())
                torpedo.set_x_location(new_spot_x)
                torpedo.set_y_location(new_spot_y)
                torpedo.reduce_life_time()
            else:
                self.__torpedo.remove(torpedo)
                self.__screen.unregister_torpedo(torpedo)

    def collision_check(self):
        """
        Function that check if torpedo hit an asteroid
        """
        for torpedo in self.__torpedo:
            for asteroid in self.__asteroids_in_game:
                if asteroid.has_intersection(torpedo):
                    if asteroid.get_size() == 3:
                        self.points += 20
                    elif asteroid.get_size() == 2:
                        self.points += 50
                    elif asteroid.get_size() == 1:
                        self.points += 100
                    self.asteroid_split(asteroid, torpedo)
        self.__screen.set_score(self.points)

    def asteroid_split(self, asteroid, torpedo):
        """
        Helping function that creates the splitting of the astroids if
        the size is bigger than 1 and deletes the former astroid.
        :param asteroid: Astroid object
        :param torpedo: Torpedo object
        """
        if asteroid.get_size() > 1:
            new_size = asteroid.get_size() - 1
            x_location = asteroid.get_location_x()
            y_location = asteroid.get_location_y()
            new_speed_x = calc_asteroid_speed(
                torpedo.get_x_speed(), asteroid.get_speed_x(),
                asteroid.get_speed_x(), asteroid.get_speed_y())  # set
            # the new x speed
            new_speed_y = calc_asteroid_speed(
                torpedo.get_y_speed(), asteroid.get_speed_y(),
                asteroid.get_speed_x(), asteroid.get_speed_y())  # get
            # the new y speed
            new_asteroid_1 = Asteroid(x_location, y_location,
                                      new_speed_x, new_speed_y,
                                      new_size)
            new_asteroid_2 = Asteroid(x_location, y_location,
                                      -1 * new_speed_x, -1 * new_speed_y,
                                      new_size)
            self.__asteroids_in_game.append(new_asteroid_1)
            self.__asteroids_in_game.append(new_asteroid_2)
            self.__screen.register_asteroid(new_asteroid_1, new_size)
            self.__screen.register_asteroid(new_asteroid_2, new_size)
        self.__asteroids_in_game.remove(asteroid)
        self.__screen.unregister_asteroid(asteroid)
        self.__torpedo.remove(torpedo)
        self.__screen.unregister_torpedo(torpedo)

    def initialize_asteroids(self):
        """
        A function that creates an asteroid array
        :return: The list asteroids
        """
        asteroids = []
        for i in range(self.__asteroids_amount):
            asteroids.append(self.create_asteroid())
        return asteroids

    def create_asteroid(self):
        """
        A function that creates a single asteroid
        :return: the object asteroid
        """
        location_x, location_y = get_random_location()
        while has_intersection_with_object_location(location_x, location_y, self.__ship.get_x_location(),
                                                    self.__ship.get_y_location(), self.__ship.get_radius()):
            location_x, location_y = get_random_location()
        asteroid = Asteroid(location_x, location_y, random.randint(1, 4), random.randint(1, 4), 3)
        self.__screen.register_asteroid(asteroid, 3)
        return asteroid

    def update_asteroids(self):
        """
        function that updates the locations of the asteroids in the game
        """
        for asteroid in self.__asteroids_in_game:
            self.__screen.draw_asteroid(asteroid, asteroid.get_location_x(), asteroid.get_location_y())
            asteroid.set_location_x(calc_new_spot(self.__screen_max_x, self.__screen_min_x, asteroid.get_location_x(),
                                                  asteroid.get_velocity_x()))
            asteroid.set_location_y(calc_new_spot(self.__screen_max_y, self.__screen_min_y, asteroid.get_location_y(),
                                                  asteroid.get_velocity_y()))


def main(amount):
    runner = GameRunner(amount)
    runner.run()


if __name__ == "__main__":
    if len(sys.argv) > 1:
        main(int(sys.argv[1]))
    else:
        main(DEFAULT_ASTEROIDS_NUM)
