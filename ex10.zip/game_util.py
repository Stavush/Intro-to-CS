from screen import *
import random
import math

INIT_TRIES = 3
INIT_POINTS = 0
SHIP_RADIUS = 1
TORPEDO_RADIUS = 4
INIT_LIFETIME = 200
TORPEDO_DEATH_INDICATOR = 0
DEFAULT_ASTEROIDS_NUM = 5
SIZE_OPTIONS = [1, 2, 3]
INITIAL_ASTEROID_RADIUS = 3 * 10 - 5

# This file is an assisting file which holds all the assisting
# functions that we didn't put in the Class. We opened the file in
# order that the asteroid_main file will not look loaded.

def get_random_location():
    """ This function returns a random location on the board"""
    return random.randint(Screen.SCREEN_MIN_X, Screen.SCREEN_MAX_X), \
           random.randint(Screen.SCREEN_MIN_Y, Screen.SCREEN_MAX_Y)


def calc_new_spot(screen_max, screen_min, old_spot, speed):
    """
    This function performs a general calculation of the formula to
    NewSpot
    :param screen_min: an attribute of screen
    :param screen_max: an attribute of screen
    :param old_spot: the current i location of the ship
    :param speed: the current i speed of the ship
    :return: the calculation
    """
    d = (screen_max - screen_min)
    return screen_min + (old_spot + speed - screen_min) % d


def calc_asteroid_speed(torpedo_speed, old_asteroid_speed,
                        old_asteroid_speed_x, old_asteroid_speed_y):
    """
    This function calculates the asteroid speed after the torpedo hits it
    """
    return (torpedo_speed + old_asteroid_speed) / math.sqrt((old_asteroid_speed_x ** 2) + (old_asteroid_speed_y ** 2))


def has_intersection_with_object_location(asteroid_location_x, asteroid_location_y,
                                          object_location_x, object_location_y, object_radius,
                                          asteroid_radius=INITIAL_ASTEROID_RADIUS):
    """
    This function checks if there's an intersection between an asteroid
    and another object
    """
    distance = math.sqrt(
        math.pow(object_location_x - asteroid_location_x, 2) + math.pow(object_location_y - asteroid_location_y, 2))
    return distance <= asteroid_radius + object_radius
