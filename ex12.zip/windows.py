import tkinter as tk

WORDS_FILE = 'boggle_dict.txt'
GAME_START = 0.0
GAME_END = 180
ROWS = 4
COLS = 4


class Windows:
    def __init__(self, parent, text1, button_function):
        self.parent = parent
        self.root = tk.Frame(self.parent)
        self.text = tk.StringVar(self.root)
        text_frame = tk.Frame(self.root)
        text_label = tk.Label(text_frame, textvariable=self.text, height=10)
        text_label.pack(side=tk.TOP)
        text_frame.place(relx=0.25, rely=0.15)
        first_button = tk.Frame(self.root)
        first_button.pack()
        first_button.place(relx=0.4, rely=0.5)
        start_button = tk.Button(first_button, text=text1, command=button_function)
        start_button.pack(side=tk.TOP)
        second_button = tk.Frame(self.root)
        second_button.pack()
        second_button.place(relx=0.6, rely=0.5)
        quit_button = tk.Button(first_button, text="Quit", command=self.__end_game)
        quit_button.pack(side=tk.BOTTOM)

    def __end_game(self):
        """
        Function that ends the current game.
        """
        self.parent.destroy()
        self.parent.quit()

    def set_text(self, text):
        self.text.set(text)

