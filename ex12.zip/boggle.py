import time

from board import *
from boggle_board_randomizer import *
from windows import Windows

GAME_END = 180
GAME_START = 0.0
WORDS_FILE = 'boggle_dict.txt'
ROWS = 4
COLS = 4
MAIN_WINDOW = 0
BOARD_WINDOW = 1
END_WINDOW = 2
End_WINDOW_TEXT = "Good Game! Your Score in The Last Game Was: {}"


class Boggle_Game:
    def __init__(self, rows=ROWS, columns=COLS, total_game_time=GAME_END):
        self.root = tk.Tk()
        self.root.title('Boggle game')
        self.rows = rows
        self.columns = columns
        self.windows = []
        self.board_data = randomize_board()
        self.score = 0
        self.current_chosen_word = []
        self.board_buttons = []
        self.all_words = Boggle_Game.words_list(WORDS_FILE)
        self.found_words = []
        self.start_time = time.time()
        self.passed_time = GAME_START
        self.total_game_time = total_game_time
        self.initialize_boggle_game_frames()
        self.windows[BOARD_WINDOW].update_timer(self.total_game_time)

    def initialize_boggle_game_frames(self):
        """
        Function that initialize the frames of the game
        """
        container = tk.Frame(self.root)
        container.pack(side="top", fill="both", expand=True)
        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)
        #bg = tk.PhotoImage(file='background.png')
        #label_bg = tk.Label(container, image=bg)
        #label_bg.pack(container, fill="both")
        board_frame = Board(container, self.rows, self.columns, GAME_END, self.validity_function,
                            self.check_chosen_word)
        board_frame.root.grid(row=0, column=0, sticky="nsew")
        main_frame = Windows(container, "Start Game!", self.raise_board)
        main_frame.root.grid(row=0, column=0, sticky="nsew")
        last_frame = Windows(container, "Play Again!", self.raise_board)
        last_frame.root.grid(row=0, column=0, sticky="nsew")
        self.windows.append(main_frame)
        self.windows.append(board_frame)
        self.windows.append(last_frame)
        self.windows[MAIN_WINDOW].root.tkraise()

    def raise_board(self):
        """
        Function that swipes between the frames
        """
        self.start_time = time.time()
        self.found_words = []
        self.windows[BOARD_WINDOW].reset_board(self.__update_game_timer)

    def __not_in_found_words(self, word):
        """
        Function that checks if the word already found
        :param word: the word that the player finds
        :return: boolean
        """
        if word not in self.found_words:
            return True
        return False

    def __add_to_score(self, word):
        """
        A function that updates the score acorrding to the length of
        the word.
        :param word: the word that was created
        """
        if self.__not_in_found_words(word):
            self.score += (len(word)) ** 2
        # add a function that updates it to the score board

    def __update_word_in_found_words(self, word):
        """
        A function that checks if the word has already been found and
        adds the word to the word list otherwise.
        """
        if word not in self.found_words:
            self.found_words.append(word)

    def __update_game_timer(self):
        """
        Function that updates the timer in the game
        """
        self.passed_time = time.time() - self.start_time
        if self.total_game_time - self.passed_time > 0:
            self.windows[BOARD_WINDOW].update_timer(self.total_game_time - self.passed_time)
            self.windows[BOARD_WINDOW].root.after(50, self.__update_game_timer)
        else:
            self.windows[END_WINDOW].set_text(End_WINDOW_TEXT.format(self.windows[BOARD_WINDOW].get_score()))
            self.windows[END_WINDOW].root.tkraise()

    def validity_function_helper(self, buttons, pressed_buttons, i, j, visited_buttons):
        """
        helper function to the function 'validity_function' that checks the validity of the buttons that the player presses
        """
        if 0 <= i < self.rows and 0 <= j < self.columns and buttons[i][j] not in visited_buttons:
            visited_buttons.append(buttons[i][j])
            if buttons[i][j]['bg'] == PRESSED:
                pressed_buttons.remove(buttons[i][j])
                for neighbour_index in Boggle_Game.get_neighbour_indices(i, j):
                    self.validity_function_helper(buttons, pressed_buttons, neighbour_index[0], neighbour_index[1],
                                                  visited_buttons)

    def validity_function(self, buttons):
        """
        function that checks the validity of the buttons that the player presses
        :param buttons: button
        """
        pressed_buttons, indices = self.windows[BOARD_WINDOW].get_pressed_buttons_data()
        if len(pressed_buttons) > 1:
            self.validity_function_helper(buttons, pressed_buttons, indices[0][0], indices[0][1], [])
            if len(pressed_buttons) != 0:
                return False
        return True

    def check_chosen_word(self, word):
        """
        Function that checks if the chosen word is not in the list of the found_words
        :param word: the chosen word
        :return: the score on the word
        """
        if word not in self.found_words and word in self.all_words:
            self.found_words.append(word)
            return len(word) ** 2
        return 0

    def run_game(self):
        """
        Function that run the game
        """
        # all the actions go here
        self.windows[BOARD_WINDOW].root.mainloop()

    @staticmethod
    def words_list(file):
        """
        Helping function that opens the words file and returns a list
        of the words
        :param file: directory of the file
        :return: list of words
        """
        words = []
        with open(file) as words_file:
            for line in words_file:
                word = line.strip()
                if word.isalpha():  # checks if the word has only abc chars
                    words.append(line.strip())
        return words

    @staticmethod
    def get_neighbour_indices(i, j):
        """
        Function that gets the indices around specific index
        :return: the indices
        """
        indices = [(i + 1, j), (i + 1, j - 1),
                   (i + 1, j + 1), (i - 1, j),
                   (i - 1, j - 1), (i - 1, j + 1),
                   (i, j + 1), (i, j - 1)]
        return indices


def main():
    boggle = Boggle_Game()
    boggle.run_game()


if __name__ == "__main__":
    main()
