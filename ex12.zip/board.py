import tkinter as tk
from tkinter.constants import *

from boggle_board_randomizer import *


RELEASE_ALL_BUTTONS = 1
RELEASE_PRESSED_BUTTONS = 0
SCORE_TEXT_START = "Score: "
RELEASED = "yellow"
PRESSED = "green"


class Board:
    def __init__(self, parent, rows, cols, game_period, validity_custom_function, answer_check_custom_function):
        """
        This function initializes the board
        """
        self.score = 0
        self.parent = parent
        self.rows = rows
        self.columns = cols
        self.board_buttons = []
        self.board_data = []
        self.__init_board()
        self.chosen_letters = ""
        self.label = tk.Label(text="")
        self.label.pack()
        self.answer_check_function = answer_check_custom_function
        self.validity_function = validity_custom_function
        self.game_period = game_period

    def __init_string_variables(self, parent):
        """
        initialize matrix of string variable
        :param parent: one of the frames
        :return: board
        """
        board = []
        for i in range(self.rows):
            board.append([])
            for j in range(self.columns):
                board[i].append(tk.StringVar(parent))
        return board

    def __randomize_board_variable(self):
        """
        Function that randomize new board after ending of a game
        """
        buttons_strings = randomize_board()
        for i in range(self.rows):
            for j in range(self.columns):
                self.board_data[i][j].set(buttons_strings[i][j])

    def __init_buttons_grid(self):
        """
        initialize the grid of the buttons with the letters
        :return:
        """
        grid_frame = tk.Frame(self.root, relief=RIDGE, borderwidth=70,
                              bg='blue')
        grid_frame.pack(side=tk.LEFT, expand=True)
        self.board_data = self.__init_string_variables(grid_frame)
        self.__randomize_board_variable()
        for i in range(self.rows):
            self.board_buttons.append([])
            for j in range(self.columns):
                button = tk.Button(grid_frame, textvariable=self.board_data[i][j],
                                   bg='yellow', height=
                                   2, width=5, font=20, relief=RAISED)
                button.config(command=lambda arg=button: self.__on_button_press(arg))
                button.grid(row=i, column=j)
                self.board_buttons[i].append(button)

    def __init_words_frame(self, side_frame):
        """
        initialize the frame of the words that found in the game
        :param side_frame: frame
        """
        words_frame = tk.Frame(side_frame)
        words_label = tk.Label(words_frame, text='Words found',
                               bg='green')
        words_label.pack(side=tk.TOP, fill=tk.BOTH)
        self.words_box = tk.Listbox(words_frame)
        self.words_box.pack()
        words_frame.pack(side=tk.BOTTOM, fill=tk.BOTH, expand=True)

    def __init_board(self):
        """
        A function that creates a board
        :return:
        """
        # the bar
        self.root = tk.Frame(self.parent)
        headline_label = tk.Label(self.root, text='Boggle', height=3,
                                  bg='pink')
        headline_label.pack(side=tk.TOP, fill=tk.BOTH)
        side_frame = tk.Frame(self.root)
        score_frame = tk.Frame(side_frame, height=5)
        score_frame.pack(side=tk.TOP, expand=True, fill=tk.BOTH)
        timer_frame = tk.Frame(side_frame, height=8)
        timer_frame.pack(expand=True, fill=tk.BOTH)
        self.__init_buttons_grid()
        self.timer = tk.StringVar(timer_frame)
        timer_headline_label = tk.Label(timer_frame, textvariable=self.timer,
                                        bg='grey')
        timer_headline_label.pack(fill=tk.BOTH)
        self.__init_words_frame(side_frame)
        side_frame.pack(side=tk.RIGHT, fill=tk.BOTH,
                        expand=True)
        # creating the window of the score and updating it:
        self.score_viewer = tk.StringVar(score_frame)
        self.score_viewer.set(SCORE_TEXT_START + str(self.score))
        window_score = tk.Label(score_frame, textvariable=self.score_viewer, bg='red')
        window_score.pack(fill=BOTH)
        send = tk.Button(score_frame, text="send",
                         command=self.on_send_click)
        send.pack(expand=True)

    def reset_board(self, update_function_timer):
        """
        function that initialize new board
        :param update_function_timer:
        :return:
        """
        self.chosen_letters = ""
        self.__randomize_board_variable()
        self.update_timer(self.game_period)
        self.__release_buttons()
        self.score = 0
        self.words_box.delete(0, tk.END)
        self.score_viewer.set(SCORE_TEXT_START+str(0))
        self.root.after(50, update_function_timer)
        self.root.tkraise()

    def __release_buttons(self):
        """
        function that allows to release all the buttons
        """
        for row in self.board_buttons:
            for button in row:
                self.__release_button(button)

    def __release_button(self, button):
        """
        function that release the button in case the player regret its choise
        :param button:
        :return:
        """
        button['bg'] = RELEASED
        button['activebackground'] = '#ececec'
        button['relief'] = 'raised'

    def __press_button(self, button):
        """
        function that allow to press a button and change its color once it is pressed
        :param button:
        :return:
        """
        button['bg'] = PRESSED
        button['activebackground'] = 'green'
        button['relief'] = 'sunken'

    def __on_button_press(self, button_widget):
        """
        function that corresponds to pressing on a letters button
        :param button_widget: the pressed button
        """

        if button_widget['bg'] == "green":
            self.chosen_letters = ""
            self.__release_buttons()
        else:
            self.__press_button(button_widget)
            if self.validity_function(self.board_buttons):
                self.chosen_letters += button_widget['text']
            else:
                self.__release_button(button_widget)

    def on_send_click(self):
        """
        function that update the score if the word correct and update the frame of the found_words
        """
        tmp = self.answer_check_function(self.chosen_letters)
        if tmp != 0:
            self.score += tmp
            self.score_viewer.set(SCORE_TEXT_START + str(self.score))
            self.words_box.insert(tk.END, self.chosen_letters)
            self.chosen_letters = ""
        self.__release_buttons()

    def get_pressed_buttons_data(self):
        """
        function that return the letter of the buttons
        """
        pressed_button = []
        indices = []
        for i in range(self.rows):
            for j in range(self.columns):
                if self.board_buttons[i][j]['bg'] == PRESSED:
                    pressed_button.append(self.board_buttons[i][j])
                    indices.append((i, j))
        return pressed_button, indices

    def get_score(self):
        """
        function that return the score
        :return: score
        """
        return self.score

    def update_timer(self, time):
        """
        function that update the timer
        """
        minutes = int(time / 60.0)
        seconds = int(time - minutes * 60.0)
        mseconds = int((time - minutes * 60.0 - seconds) * 100.0)
        self.timer.set('%02d:%02d:%02d' % (minutes, seconds, mseconds))
