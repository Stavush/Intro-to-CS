"""Part 7 - a function that gets a threshold temperature and three
temperatures that were measured in three consecutive days"""
def is_it_summer_yet(threshold, temp1, temp2, temp3):
    if (temp1 > threshold and temp2 > threshold) or \
            (temp3 > threshold and temp2 > threshold) or \
            (temp1 > threshold and temp3 > threshold):
        return True
    else:
        return False