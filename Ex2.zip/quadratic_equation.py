""" part 4 - functcion that gets 3 coefficients a,b,c and returns the
solutions of the quadratic equation"""

def quadratic_equation(a,b,c):
    delta=(b**2)-(4*a*c)
    x1 = ((-b) + (delta ** 0.5)) / (2 * a)
    x2 = ((-b) - (delta ** 0.5)) / (2 * a)

    if delta>0:
        return (x1, x2)
    elif delta==0:
        return(x1,None)
    else:
        return (None,None)

"""part 6 - function that asks for 3 coefficients and returns how many 
solutions there are + the solutions"""
def quadratic_equation_user_input():
    text=input("Insert coefficients a, b, and c: ")
    nums=text.split(' ')
    a=float(nums[0])
    b=float(nums[1])
    c=float(nums[2])

    if a==0:
        print ("The parameter 'a' may not equal 0")
    else:
        check=quadratic_equation(a,b,c)
        if check[0]!=None and check[1]!=None:
            print("The equation has 2 solutions:", check[0], "and", check[1])
        if (check[0]!=None and check[1]==None):
            print("The equation has 1 solution:", check[0])
        if (check[0]==None and check[1]==None):
            print ("The equation has no solutions")