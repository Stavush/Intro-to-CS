""" part 3 - function that gets 3 numbers and returnes the largest and the
smallest number"""

def largest_and_smallest(num1, num2, num3):
    if num1 >= num2 and num1 >= num3:
        if num2>num3:
            return (num1, num3)
        else:
            return (num1, num2)
    if num2 >= num1 and num2 >= num3:
            if num1 > num3:
                return (num2, num3)
            else:
                return (num2, num1)
    if num3 >= num1 and num3 >= num2:
            if num1 > num2:
                return(num3, num2)
            else:
                return (num3, num1)

""" Part 8 - function that checks the liability of the function 
largest_and_smallest() I chose those inputs because the 
first case checks 2 largest and thesecond case checks 3 even numbers"""
def check_largest_and_smallest():
    x = largest_and_smallest(17,1,6)
    corrects=0
    if x[0] == 17 and x[1] == 1:
        corrects += 1
    x = largest_and_smallest(1,17,6)
    if x[0] == 17 and x[1] == 1:
        corrects += 1
    x = largest_and_smallest(1,1,2)
    if x[0] == 2 and x[1] == 1:
        corrects += 1
    x = largest_and_smallest(10,0,10)
    if x[0] == 10 and x[1] == 0:
        corrects += 1
    x = largest_and_smallest(0,0,0)
    if x[0] == 0 and x[1] == 0:
        corrects += 1
    if corrects == 5:
        return True
    else:
        return False