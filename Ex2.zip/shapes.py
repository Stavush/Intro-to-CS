"""part 6 - function that asks for a chosen shape and parameters and
calculates the area of the shape"""
import math

def shape_area():
    shape = int(input("Choose shape (1=circle, 2=rectangle, 3=triangle): "))
    if shape !=1 and shape != 2 and shape != 3:
        return None
    else:
        if shape == 1:
            radius = float(input())
            return (math.pi*(radius**2))
        if shape == 2:
            x = float(input())
            y = float(input())
            return (x*y)
        else:
            a = float(input())
            return (((3**0.5)/4)*(a**2))