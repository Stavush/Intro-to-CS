"""part 1 - function that gets 2 numbers and a math argument (+-/*) and
calculates it """
def calculate_mathematical_expression(a,b,math_argument):
    if math_argument=='+':
        return (a+b)
    elif math_argument=='-':
        return (a-b)
    elif math_argument=='*':
        return (a*b)
    elif math_argument=='/':
        if b != 0:
            return (float(a/b))

"""part 2 - function that gets sms content, splits it into desired 
calculation and calculates it using the function 
calculate_mathematical_expression"""
def calculate_from_string(sms):
    vals=sms.split(' ')
    return(calculate_mathematical_expression(float(vals[0]), float(vals[-1]),
                                             vals[1]))