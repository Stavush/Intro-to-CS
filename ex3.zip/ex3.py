"""Q.1 - The function gets strings of numbers until an empty input is being
sent and returns a list of the integers and their sum as the final number in
the list """

def input_list():
    num_list = []
    sum_of_nums = 0
    num = input()
    while num != "":
        num = int(num)
        num_list.append(num)
        sum_of_nums += num
        num = input()
    num_list.append(sum_of_nums)
    return num_list


"""Q.2 - The function gets 2 lists of numbers. If the lists' lengths are not
equal, the function returns None, else it returns the sum of the multiplication
of two numbers in the same places in the lists"""

def inner_product(vec1, vec2):
    sum = 0
    if len(vec1) == len(vec2):
        for i in range(len(vec1)):
            sum += vec1[i]*vec2[i]
        return sum
    else:
        return None


""" Q.3 - A function that gets a list of numbers and return bollean values 
of the monotonicity of the list (is rising, is riding much, is descending, 
is descending much)"""
def sequence_monotonicity(sequence):
    is_rising = 0
    is_rising_much = 0
    output = [True, True, True, True]
    if output == []:
        return output
    for i in range(len(sequence)-1):
        if sequence[i] <= sequence[i+1]:
            """if the number in [i] is lower or equal to the next one the 
            counter grows by 1"""
            is_rising += 1
        if sequence[i] < sequence[i+1]:
            """if the number in [i] is lower than the next one the counter
             grows by 1"""
            is_rising_much += 1
    if is_rising != len(sequence)-1:
        """ if the counter is not equal to the the times the loop ran, 
        that means that the series is not rising"""
        output[0] = False
    if is_rising_much != len(sequence)-1:
        """ if the counter is not equal to the the times the loop ran, 
        that means that the series is not rising much"""
        output[1] = False
    if is_rising_much != 0:
        """If the couner is not equal to 0 that means that the series is not 
        descending"""
        output[2] = False
    if is_rising != 0:
        """If the couner is not equal to 0 that means that the series is not 
        descending much"""
        output[3] = False
    return (output)


""" Q.4 - A function that gets a list of terms regarding the decline or rise of
 numbers in a list as booleans and returns an example list that matches the 
 terms"""
def monotonicity_inverse(def_bool):
    return_list = []
    if (def_bool[0] == def_bool[3] or def_bool[1] == def_bool[2]):
        return None
    else:
        if def_bool[0] == True and def_bool[1] == True:
            return ([1,2,3,4])
        elif def_bool[0] == True and def_bool[1] != True:
            return ([1,2,3,4])
        elif def_bool[2] == True and def_bool[3] == True:
            return ([4,3,2,1])
        elif def_bool[2] == True and def_bool[3] != True:
            return ([3,2,2,1])


"""Q.5 - A function that prints the n primary numbers from 2"""
def primes_for_asafi(n):
    lst = []
    i = 2
    while len(lst) < int(n):
        count_divides = 0
        for j in range(2,i):
            if i == 2:
                lst.append(i)
            if i != 2:
                if i%j == 0:
                    count_divides += 1
        if count_divides == 0:
            lst.append(i)
        i += 1
    return (lst)


"""Q.6 - A function that gets 2 lists of numbers and returns a list of the 
sum of the numbers in the same position but in different vectors"""

def sum_of_vectors(vec_lst):
    result = []
    position = 0
    while position <= len(vec_lst[0])-1:
        sum = 0
        for vector in vec_lst:
            sum += vector[position]
        result.append(sum)
        position += 1
    return (result)


"""Q.7 - A function that gets to lists of numbers and returns whether 
the lists are orthogonal to each other using the function in the second 
question in this HW"""

def num_of_orthogonal(vectors):
    count = 0
    for i in vectors:
        for j in vectors:
            if i !=j:
                if inner_product(i,j) == 0:
                    count += 1
    return (int(count/2))
