def secret_function():
    print('My username is stavben and I have read the submission response.')

if __name__ == "__main__":
    secret_function()
