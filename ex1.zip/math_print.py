import math

#funtion that prints the golden ratio

def golden_ratio():
    print((1+math.sqrt(5))/2)

#function that prints 6^2
def six_squared():
    print(math.pow(6,2))

#function that prints the 3rd edge of a 90 degrees triangle
def hypotenuse():
    print(math.hypot(5,12))

#function that prints the numerical value of pi
def pi():
    print(math.pi)

#function that prints the numerical value of e
def e():
    print(math.e)

#function that prints the areas of squares with edges rrom 1 t0 10
def squares_area():
    print(1**2,2**2,3**2,4**2,5**2,6**2,7**2,8**2,9**2,10**2)

#calling the functions    
if __name__ == "__main__":
    golden_ratio()
    six_squared()
    hypotenuse()
    pi()
    e()
    squares_area()

