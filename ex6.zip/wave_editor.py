#############################################################
# FILE : wave_editor.py
# EXERCISE : intro2cs1 ex6 2019-2020
# DESCRIPTION : A program that edits wav files.
#############################################################

import wave_helper
import math
import os

FRAME_RATE = 2000
MAX_VOLUME = 32767  # maximum value as defined
MIN_VOLUME = -32768  # minimum value as defined

EDITING = '1'
COMPOSING = '2'
EXIT = '3'

REVERSE = '1'
SPEED_UP = '2'
SPEED_DOWN = '3'
VOL_UP = '4'
VOL_DOWN = '5'
LOW_PASS = '6'
EXIT_INNER = '7'

note_frequency = {
    'A': 440,
    'B': 494,
    'C': 523,
    'D': 587,
    'E': 659,
    'F': 698,
    'G': 784,
    'Q': 0,
}


# The next few functions belong to part 1 - editing a wav file.

def entrance_menu():
    """entrance menu func. checks if the values are valid
    and calls: changing_wav(), compose_menu() or exit_menu()"""
    correct_input = False
    while correct_input is False:  # keeps loading the menu while
        # there's a problem with the input
        choice = input("Welcome to Wave Editor! Please choose your "
                       "preferred option: \n (1) Changing .wav file \n (2) "
                       "Composing in format that matches .wav file \n ("
                       "3) Exiting the program \n")
        if choice == '1':
            correct_input = True
            changing_wav_file()
        if choice == '2':
            correct_input = True
            compose_menu()
        if choice == '3':
            correct_input = False
            return
        # if choice != '1' and choice != '2' and choice != '3':
        #     print("Input error")
        #     entrance_menu()


def changing_wav_file():
    """This function checks validation of input file path from the user.
    If valid, it loads the file and calls the function edit_file_menu."""
    file_name = input("Please enter the .wav file name: ")
    if file_name == "":  # if the user didn't send a name.
        print("You didn't enter a file")
        changing_wav_file()
    # if file_name[-4:] != ".wav":
    #     file_name = file_name + ".wav"
    else:
        file_to_edit = wave_helper.load_wave(file_name)
        edit_file_menu(file_to_edit)


def edit_file_menu(file_to_edit):
    """a menu that calls functions that edit the wave file.
        It keeps showing the menu as long as the user doesn't choose the exit menu."""
    editing_options = 0
    while editing_options != '7':
        editing_options = input("Please enter the change that you want "
                                "to "
                                "perform: \n (1) reversing \n (2) speeding "
                                "up \n (3) speeding down \n (4) volume up "
                                "\n (5) volume down \n (6) low pass filter \n "
                                "(7) move to exit menu \n")
        if editing_options == '1':
            file_to_edit = reverse(file_to_edit)
            print("File reversed")
            continue
        if editing_options == '2':
            file_to_edit = speeding_up(file_to_edit)
            print("File speed is up")
            continue
        if editing_options == '3':
            file_to_edit = speeding_down(file_to_edit)
            print("File speed is down")
            continue
        if editing_options == '4':
            file_to_edit = volume_up(file_to_edit)
            print("File volume is up")
            continue
        if editing_options == '5':
            file_to_edit = volume_down(file_to_edit)
            print("File volume is down")
            pass
        if editing_options == '6':
            file_to_edit = low_pass(file_to_edit)
            print("File is low passed")
            continue
        if editing_options == '7':
            exit_menu(file_to_edit)
            continue
        # else:
        #     print("Input error")
        #     edit_file_menu(file_to_edit)


def reverse(file_to_edit):
    """
    :param file_to_edit: an opened file.
    :return: a tuple of frame_rate and the reversed audio_list using list slicing.
    """
    if file_to_edit == -1:
        print("There's something wrong with the file")
        reverse(file_to_edit)
    else:
        frame_rate = file_to_edit[0]
        audio_data = file_to_edit[1]
        reversed_audio = audio_data[::-1]
        reversed_tup = (frame_rate, reversed_audio)
        return reversed_tup


def speeding_up(file_to_edit):
    """
    :param file_to_edit: loaded file.
    :return: a tuple of frame_rate and a list of the values of audio_data in even places
    """
    if file_to_edit == -1:
        print("There's something wrong with the file")
        return -1
    else:
        frame_rate = file_to_edit[0]
        audio_data = file_to_edit[1]
        speed_up_file = audio_data[::2]
    speed_up_tup = (frame_rate, speed_up_file)
    return speed_up_tup


def speeding_down(file_to_edit):
    """
    adding the average of each 2 samples to the list, between the 2 samples.
    :param file_to_edit: a loaded file.
    :return: tuple of frame_rate and audio_data.
    """
    if file_to_edit == -1:
        print("There's something wrong with the file")
        return -1
    frame_rate = file_to_edit[0]
    audio_data = file_to_edit[1]
    speed_down = []
    for i in range(len(audio_data) - 1):
        val1 = (audio_data[i][0] + audio_data[i + 1][0]) / 2
        val2 = (audio_data[i][1] + audio_data[i + 1][1]) / 2
        speed_down.append(audio_data[i])
        speed_down.append([val1, val2])
    speed_down.append(audio_data[len(audio_data) - 1])
    speed_down_tup = (frame_rate, speed_down)
    return speed_down_tup


def volume_up(file_to_edit):
    """
    multiplying values by 1.2.
    :param file_to_edit: loaded file.
    :return: a tuple of frame_rate and audio_data.
    """
    volume_up_values = []
    if file_to_edit == -1:
        print("There's something wrong with the file")
        return -1
    audio_data = file_to_edit[1]
    frame_rate = file_to_edit[0]
    for i in audio_data:
        sample = []
        for j in i:
            loud_vol = int(j * 1.2)
            if MAX_VOLUME >= loud_vol >= MIN_VOLUME:
                sample.append(loud_vol)
            if loud_vol > MAX_VOLUME:
                sample.append(MAX_VOLUME)
            if loud_vol < MIN_VOLUME:
                sample.append(MIN_VOLUME)
        volume_up_values.append(sample)
    volume_up_tup = (frame_rate, volume_up_values)
    return volume_up_tup


def volume_down(file_to_edit):
    """
    dividing values by 1.2.
    :param file_to_edit: a loaded file.
    :return: a tuple of frame_rate and audio_data.
    """
    volume_down_values = []
    if file_to_edit == -1:
        print("There's something wrong with the file")
        return -1
    frame_rate = file_to_edit[0]
    audio_data = file_to_edit[1]
    for i in audio_data:
        sample = []
        for j in i:
            low_vol = int(j / 1.2)
            if MAX_VOLUME >= low_vol >= MIN_VOLUME:
                sample.append(low_vol)
            if low_vol > MAX_VOLUME:
                sample.append(MAX_VOLUME)
            if low_vol < MIN_VOLUME:
                sample.append(MIN_VOLUME)
        volume_down_values.append(sample)
    volume_down_tup = (frame_rate, volume_down_values)
    return volume_down_tup


def low_pass(file_to_edit):
    """
    calculates the average of the previous, current and next values in the original audio_data list.
    :param file_to_edit: a loaded file.
    :return: a tuple of frame_rate and audio_data.
    """
    low_pass_array = []
    if file_to_edit == -1:
        print("There's something wrong with the file")
        return -1
    frame_rate = file_to_edit[0]
    audio_data = file_to_edit[1]
    low_pass_array.append([int((audio_data[0][0] + audio_data[1][0]) / 2)] * 2)
    for i in range(1, len(audio_data) - 1):
        low_pass_array.append([int((audio_data[i - 1][0] + audio_data[i][
            0] + audio_data[i + 1][0]) / 3)] * 2)
    low_pass_array.append([int((audio_data[len(audio_data) - 2][0]
                                + audio_data[len(audio_data) - 1][0]) / 2)] * 2)
    low_pass_tup = (frame_rate, low_pass_array)
    return low_pass_tup


def exit_menu(received_file):
    """
    Receives saved_file_name (string) and saves the file using save_wave from wave_helper.
    :param received_file: a loaded file.
    :return: None.
    """
    saved_file_name = input("Please insert the new file name: ")
    frame_rate = received_file[0]
    audio_data = received_file[1]
    # with open(saved_file_name, 'w'):
    wave_helper.save_wave(frame_rate, audio_data, saved_file_name)
    entrance_menu()


# The next few functions belong to part 2 - composing a melody.

def get_note_and_time(file_name):
    """
    This function will get the wanted notes and their length from a given instructions file,
    by creating a list of tuples containing a pair of note and its time length.
    :param file_name: An instructions file containing a string of notes and seconds (int).
    :return: A list of tuples.
    """
    content_list = []
    with open(file_name, 'r') as file:
        # the next for loop will create a list containing only the information we need.
        for line in file:
            line = line.strip('\n')
            temp_lst = line.split(' ')
            # temp_lst might still contain unwanted whitespaces.
            # the next for loop is meant to fix this.
            for i in temp_lst:
                if i.isupper() is True or i.isalnum() is True:
                    content_list.append(i)
        note_sec = []
        # the next for loop will create a list of tuples of note-second couple.
        for j in range(0, len(content_list), 2):
            note = content_list[j]
            second = content_list[j + 1]
            tup = (note, second)
            note_sec.append(tup)
        return note_sec


def create_wave(note, second):
    """
    This function creates an array of waves, represented by the numerical value of a sample.
    A sound wave is a sin function dependent on frequency and time.
    :param note: The type of note determines the wave frequency.
    :param second: The amount of time a note is being played.
    :return: A list of list which represent a sound wave.
    """
    waves_array = []
    frequency = note_frequency[note]
    second = float(second) / 16.0
    for i in range(int(FRAME_RATE * second)):
        if note is not 'Q':
            samples_per_cycle = FRAME_RATE / frequency
            sample_value = MAX_VOLUME * math.sin(math.pi * 2 * i / samples_per_cycle)
            sample_value = int(sample_value)
            waves_array.append([sample_value, sample_value])
        else:
            sample_value = 0
            waves_array.append([sample_value, sample_value])
    return waves_array


def compose(file_name):
    """
    This function will create an entire melody of a number of notes, by calling the two previous functions.
    :param file_name: An instructions file containing a string of notes and seconds (int).
    :return: A list containing information about all the notes.
    """
    waves_array = []
    note_sec = get_note_and_time(file_name)
    for tup in note_sec:
        note, second = tup[0], tup[1]
        waves_array.extend(create_wave(note, second))
    return waves_array


def compose_menu():
    """
    This function is the backbone. It receives an input, checks it and calls the rest of the functions.
    :return: A list containing information about all the notes.
    """
    msg_enter_file = "Please enter a file name and its extension: "
    file_name = input(msg_enter_file)
    while os.path.isfile(file_name) is False:
        print("file is missing.")
        file_name = input(msg_enter_file)
    waves_array = compose(file_name)
    file_to_edit = [FRAME_RATE, waves_array]
    edit_file_menu(file_to_edit)
    return waves_array


if __name__ == "__main__":
    entrance_menu()
