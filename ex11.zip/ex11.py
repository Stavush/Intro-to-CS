import itertools

YES = 1
NO = -1

class Node:
	def __init__(self, data, positive_child = None, negative_child = None):
		self.data = data
		self.positive_child = positive_child
		self.negative_child = negative_child


	def is_leaf(self):
		if self.positive_child is None and self.negative_child is None:
			return True
		
class Record:
	def __init__(self, illness, symptoms):
		self.illness = illness
		self.symptoms = symptoms
	
			
def parse_data(filepath):
	with open(filepath) as data_file:
		records = []
		for line in data_file:
			words = line.strip().split()
			records.append(Record(words[0], words[1:]))
		return records
		

class Diagnoser:
	def __init__(self, root):
		self.root = root
		
	def diagnose(self, symptoms):
		"""
		A function that gets a root of a tree and a list of
		symptoms, and returns the name of the illness that matches them
		:param symptoms: A list of symptoms (strings)
		:return: the name of the illness that matches them (string)
		"""
		if self.root.is_leaf():
			return self.root.data
		else:
			symptom = self.root.data
			if symptom in symptoms:
				diagnose = Diagnoser(self.root.positive_child)
			else:
				diagnose = Diagnoser(self.root.negative_child)
			return diagnose.diagnose(symptoms)
		
	def calculate_success_rate(self, records):
		"""
		A function that gets a root and a list of records and returns
		the success rate
		:param records: a list of Record objects
		:return: the success rate, calculated by the number of right
		diagnoses dividing to the number of records.
		"""
		success = 0
		for record in records:
			if self.diagnose(record.symptoms) == record.illness:
				success += 1
		return success/len(records)

	def all_illnesses(self):
		"""
		function that gets a root, uses a helping function to get a
		dictionary of illnesses and their frequency, sorts the
		dictionary and builds a list of illnesses by the order of their frequencies
		:return: a list of illnesses by the order of their frequencies
		"""
		all_illnesses_sorted = []
		illnesses_freq = self.all_illnesses_helper({})
		if None in illnesses_freq.keys():
			illnesses_freq.pop(None)
		sorted_freq = sorted(illnesses_freq.items(), key=lambda illness:
		illness[1], reverse=True)
		for illness in sorted_freq:
			all_illnesses_sorted.append(illness[0])
		return all_illnesses_sorted

	def all_illnesses_helper(self, illness_freq):
		"""
		Helping function that goes through the tree recursively and
		adds illnesses in the leaves and their frequency in the tree
		:param illness_freq: illnesses dictionary
		:return: dictionary of the illnesses and their frequency
		"""
		if self.root.is_leaf():
			if self.root.data in illness_freq.keys():
				if self.root.data != None:
					illness_freq[self.root.data] += 1
			else:
				illness_freq[self.root.data] = 1
			return illness_freq
		return Diagnoser(self.root.positive_child).all_illnesses_helper(
					illness_freq) and Diagnoser(
			self.root.negative_child).all_illnesses_helper(
					illness_freq)
		
	def paths_to_illness(self, illness):
		"""
		A function that gets an illness (string) and returns a list of
		the paths that goes to the leaf in which it is in.
		:param illness: A string representing an illness
		:return: A list of paths to illness leaf
		"""
		return self.paths_to_illness_helper(illness, [])

	def paths_to_illness_helper(self, illness, path):
		"""
		A  helping function that gets an illness (string) and a
		list and returns a list of the paths that goes to the leaf in
		which it is in.
		:param illness: string representing an illness
		:param path: a list
		:param all_paths: a list
		:return: list off paths
		"""
		if self.root.is_leaf():
			if self.root.data == illness:
				return [path]
			else:
				return []
		else:
			positive = Diagnoser(self.root.positive_child)
			negative = Diagnoser(self.root.negative_child)
			if self.root.positive_child and not self.root.negative_child:
				return positive.paths_to_illness_helper(illness, path + [
					True])
			if self.root.negative_child and not self.root.positive_child:
				return negative.paths_to_illness_helper(illness, path + [
					False])
			return positive.paths_to_illness_helper(illness, path + [
					True]) + negative.paths_to_illness_helper(illness,
														path + [False])


# A function that gets a list of symptoms and a list of records,
# and builds a tree base on the symptoms
def build_tree(records, symptoms):
    """
    A function that gets a list of symptoms and a list of records,
    and builds a tree base on the symptoms
    :param records: A list of record objects
    :param symptoms: A list of strings representing symptoms
    :return:
    """
    root = Node(None)
    build_tree_helper(records, symptoms, root, [])
    return root


def build_tree_helper(records, symptoms, root, path):
    """
    A helping function that builds the tree
    :param records: A list of record objects
    :param symptoms: A list of strings representing symptoms
    :param path: A list of
    :return: root of a tree
    """
    if len(symptoms) >= 1:
        root.data = symptoms[0]
        root.positive_child = Node(None)
        root.negative_child = Node(None)
        build_tree_helper(clean_records(records, path, symptoms[0], YES), symptoms[1:], root.positive_child, path + [symptoms[0]])
        build_tree_helper(clean_records(records, path, symptoms[0], NO), symptoms[1:], root.negative_child, path)
    else:
        if len(records) == 1:
            root.data = records[0].illness
        elif len(records) > 1:
            root.data = most_abundant(filter_records(records, path))


# The function below is a helping function that returns a list of
# records after removing those who don't match the path
def clean_records(records, path, symptom, yesOrNo):
    new_records = []
    for record in records:
        if symptom in record.symptoms and yesOrNo == YES:
            new_records.append(record)
        elif yesOrNo == NO and symptom not in record.symptoms:
            new_records.append(record)
    for record in new_records:
        if not check_matching_path(record.symptoms, path):
            new_records.remove(record)
    return new_records


# The function below is a helping function that checks if the entire
# path is identical to the list symptoms
def check_whole_path(symptoms, path):
    count = 0
    for symptom in path:
        if symptom not in symptoms:
            return False
        count += 1
    return count == len(symptoms)


# The function below is a helping function that checks if the path is
# matches the list symptoms
def check_matching_path(symptoms, path):
    for symptom in path:
        if symptom not in symptoms:
            return False
    return True


# The function below is a helping function that filters the records
# that match path
def filter_records(records, path):
    filtered_records = []
    for record in records:
        if check_matching_path(record.symptoms, path):
            filtered_records.append(record)
    return filtered_records


# The function below is a helping function that finds the most abundant
# illness in records
def most_abundant(records):
    illnesses = [record.illness for record in records]
    counter = 0
    illness = None
    for record in records:
        frequency = illnesses.count(record.illness)
        if frequency > counter:
            counter = frequency
            illness = record.illness
    return illness
	
def optimal_tree(records, symptoms, depth):
	"""
	function that returns the root of the optimal tree, measured by
	success rate.
	:param records: a list of record objects
	:param symptoms: a list of symptoms (strings)
	:param depth: number of levels that are to be built
	:return: the root of the optimal tree
	"""
	max_rate = 0
	max_root = None
	combinations = itertools.combinations(symptoms, depth)
	for combination in combinations:
		root = build_tree(records, combination)
		success_rate = Diagnoser(root).calculate_success_rate(records)
		if success_rate > max_rate:
			max_rate = success_rate
			max_root = root
	return max_root

if __name__ == "__main__":

	# Manually build a simple tree.
	#                cough
	#          Yes /       \ No
	#        fever           healthy
	#   Yes /     \ No
	# influenza   cold

	flu_leaf = Node("influenza", None, None)
	cold_leaf = Node("cold", None, None)
	inner_vertex = Node("fever", flu_leaf, cold_leaf)
	healthy_leaf = Node("healthy", None, None)
	root = Node("cough", inner_vertex, healthy_leaf)
	simple_diagnoser = Diagnoser(root)
	one_leaf_diagnoser = Diagnoser(flu_leaf)


	# Simple test
	diagnosis = simple_diagnoser.diagnose(["cough"])
	if diagnosis == "cold":
		print("Test passed")
	else:
		print("Test failed. Should have printed cold, printed: ", diagnosis)


	# Add more tests for sections 2-7 here.

	print("all_illnesses:", simple_diagnoser.all_illnesses())
	print("all_illnesses:", one_leaf_diagnoser.all_illnesses())
	print(simple_diagnoser.paths_to_illness('cold'))